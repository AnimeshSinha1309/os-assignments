# System Calls

The files are placed in the appropriate directories.

To run Q1: `gcc -o Q1 Q1.c && ./Q1 testfile.txt`
To run Q2: `gcc -o Q2 Q2.c && ./Q2 testfile.txt Assignment/testfile.txt Assignment/`
